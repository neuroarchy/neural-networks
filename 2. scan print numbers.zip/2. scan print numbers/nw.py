import cv2
import random
import numpy
from PIL import Image



def openImage(filename):
    return cv2.cvtColor(numpy.array(Image.open(filename)), cv2.COLOR_RGB2GRAY)

class Neuron:
    power = 0.0

class Link:
    weight = 0.0
    donor = []
    acceptor = []

class Network:
    neurons = []
    links = []

def readWeightsFromFile(nw, filename):
    f = open(filename, "rt", encoding='ansi')
    i = 0
    for line in f:
        nw.links[i].weight = float(line)
        i += 1
    f.close()
    return nw

def writeWeightsInFile(nw, filename):
    f = open(filename, "wt", encoding='ansi')
    for link in nw.links:
        f.write("{}\n".format(link.weight))
    f.close()

def clearNetwork(nw):
    for n in nw.neurons[1]:
        n.power = 0.0
    return nw

def createNetwork():
    nw = Network()
    i = 0
    nw.neurons.append([])
    while i < 45*45:
        nw.neurons[0].append(Neuron())
        i += 1
    nw.neurons.append([])
    i = 0
    while i < 10:
        nw.neurons[1].append(Neuron())
        i += 1
    h = 0
    i = 0
    while i < 10:
        j = 0
        while j < 45*45:
            nw.links.append(Link())
            nw.links[h].donor = [0, j];
            nw.links[h].acceptor = [1, i];
            nw.links[h].weight = random.random()*2-1
            j += 1
            h += 1
        i += 1
    return nw

def setInput(nw, im):
    i = 0
    for line in im:
        for pix in line:
            nw.neurons[0][i].power = pix
            i += 1
    return nw

def handle(nw, im):
    nw = setInput(nw, im)
    for ln in nw.links:
        nw.neurons[ln.acceptor[0]][ln.acceptor[1]].power += ln.weight * nw.neurons[ln.donor[0]][ln.donor[1]].power
    mx = -1000
    mxin = -1
    i = 0
    while i < 10:
        if mx < nw.neurons[1][i].power:
            mx = nw.neurons[1][i].power
            mxin = i
        i += 1
    nw = clearNetwork(nw)
    return mxin



def study(nw):
    it = 0
    ln = 500
    index = 0
    imges = []
    while index < 10:
        imges.append(openImage("{}.jpg".format(index)))
        index += 1
    while it < ln:
        i = 0
        print(it)
        while i < 10:
            im = imges[i]
            hi = 0
            for line in im:
                for pix in line:
                    nw.neurons[0][hi].power = pix
                    hi += 1
    
    
            for link in nw.links:
                if link.acceptor[1] == i:
                    link.weight += 0.5*(nw.neurons[0][link.donor[1]].power - link.weight)
            i += 1
        it += 1
    nw = clearNetwork(nw)
    return nw

nw = createNetwork()
#nw = study(nw)
#writeWeightsInFile(nw, "links.nn")
nw = readWeightsFromFile(nw, "links.nn")
im = openImage("test.jpg")


print(handle(nw, im))



#cv2.imshow('window', openImage("1.jpg"))
